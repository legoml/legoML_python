def factor_product(*factors):
    return factors[0].product(*factors[1:])